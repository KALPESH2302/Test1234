package in.org.rebit.jbpm.services;

import in.org.rebit.model.BpmnFiles;
import in.org.rebit.repository.BpmnFileRepository;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import jakarta.persistence.EntityManagerFactory;
import org.kie.api.io.ResourceType;
import org.kie.api.runtime.EnvironmentName;
import org.kie.api.runtime.KieSession;
import org.kie.api.runtime.manager.*;
import org.kie.api.task.TaskService;
import org.kie.internal.io.ResourceFactory;
import org.kie.internal.runtime.manager.RuntimeManagerRegistry;
import org.kie.internal.runtime.manager.context.EmptyContext;
import org.kie.internal.runtime.manager.context.ProcessInstanceIdContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.transaction.PlatformTransactionManager;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

@Component
public class BpmnInitializerService {

    private static final Logger logger = LoggerFactory.getLogger(BpmnInitializerService.class);

    private final EntityManagerFactory emf;
    private final RebitUserGroupCallBack rebitUserGroupCallBack;
    private final BpmnFileRepository bpmnFileRepository;
    private final PlatformTransactionManager transactionManager;

    // ✅ ReadWriteLock: multiple readers (API calls) can run in parallel
    //    only blocks all when rebuilding (write lock)
    private final ReadWriteLock rwLock = new ReentrantReadWriteLock();
    private volatile RuntimeManager runtimeManager;

    public BpmnInitializerService(EntityManagerFactory emf,
                                  RebitUserGroupCallBack rebitUserGroupCallBack,
                                  BpmnFileRepository bpmnFileRepository,
                                  PlatformTransactionManager transactionManager) {
        this.emf = emf;
        this.rebitUserGroupCallBack = rebitUserGroupCallBack;
        this.bpmnFileRepository = bpmnFileRepository;
        this.transactionManager = transactionManager;
    }

    @PostConstruct
    public void initRuntimeManager() {
        rwLock.writeLock().lock();
        try {
            this.runtimeManager = createRuntimeManager();
            logger.info("RuntimeManager initialized successfully");
        } finally {
            rwLock.writeLock().unlock();
        }
    }

    private RuntimeManager createRuntimeManager() {
        RuntimeEnvironmentBuilder builder = RuntimeEnvironmentBuilder.Factory.get()
                .newDefaultBuilder()
                .entityManagerFactory(emf)
                .userGroupCallback(rebitUserGroupCallBack)
                .addEnvironmentEntry(EnvironmentName.TRANSACTION_MANAGER, transactionManager)
                .addEnvironmentEntry(EnvironmentName.ENTITY_MANAGER_FACTORY, emf)
                .persistence(true);

        List bpmnFiles = bpmnFileRepository.findAll();
        for (BpmnFiles bpmnFile : bpmnFiles) {
            builder.addAsset(
                    ResourceFactory.newByteArrayResource(
                            bpmnFile.getFileContent().getBytes(StandardCharsets.UTF_8)),
                    ResourceType.BPMN2
            );
        }

        RuntimeEnvironment env = builder.get();

        // ✅ Per-Process-Instance: each process instance gets its own KieSession
        //    Different process instances run FULLY PARALLEL
        //    Same process instance is safely serialized by jBPM internally
        return RuntimeManagerFactory.Factory.get()
                .newPerProcessInstanceRuntimeManager(env, "ppi-rm-" + System.currentTimeMillis());
    }

    /**
     * ✅ For NEW process creation (no process instance ID yet)
     */
    public RuntimeEngine getRuntimeEngineForNew() {
        rwLock.readLock().lock();
        try {
            return runtimeManager.getRuntimeEngine(EmptyContext.get());
        } finally {
            rwLock.readLock().unlock();
        }
    }

    /**
     * ✅ For EXISTING process instances — routes to the correct KieSession
     *    Enables parallel execution across different process instances
     */
    public RuntimeEngine getRuntimeEngine(Long processInstanceId) {
        rwLock.readLock().lock();
        try {
            return runtimeManager.getRuntimeEngine(
                    ProcessInstanceIdContext.get(processInstanceId));
        } finally {
            rwLock.readLock().unlock();
        }
    }

    public void disposeRuntimeEngine(RuntimeEngine engine) {
        rwLock.readLock().lock();
        try {
            runtimeManager.disposeRuntimeEngine(engine);
        } finally {
            rwLock.readLock().unlock();
        }
    }

    public TaskService getTaskService(RuntimeEngine engine) {
        return engine.getTaskService();
    }

    public KieSession getKieSession(RuntimeEngine engine) {
        return engine.getKieSession();
    }

    /**
     * ✅ Rebuild with write lock — blocks all API calls briefly during reload
     */
    public void rebuild() {
        rwLock.writeLock().lock();
        try {
            closeRuntimeManagerInternal();
            this.runtimeManager = createRuntimeManager();
            logger.info("RuntimeManager rebuilt successfully");
        } finally {
            rwLock.writeLock().unlock();
        }
    }

    private void closeRuntimeManagerInternal() {
        if (runtimeManager != null) {
            logger.info("Closing RuntimeManager");
            runtimeManager.close();
            RuntimeManagerRegistry.get().remove(runtimeManager);
            runtimeManager = null;
            logger.info("RuntimeManager closed and deregistered");
        }
    }

    @PreDestroy
    public void shutdown() {
        rwLock.writeLock().lock();
        try {
            closeRuntimeManagerInternal();
        } finally {
            rwLock.writeLock().unlock();
        }
    }
}
