package in.org.rebit.jbpm.services;

import in.org.rebit.dto.request.TaskLifeCycleDto;
import in.org.rebit.dto.response.TaskSummaryDto;
import in.org.rebit.model.BpmnFiles;
import in.org.rebit.repository.BpmnFileRepository;
import jakarta.transaction.Transactional;
import org.kie.api.runtime.manager.RuntimeEngine;
import org.kie.api.runtime.process.ProcessInstance;
import org.kie.api.task.TaskService;
import org.kie.api.task.model.Status;
import org.kie.api.task.model.TaskSummary;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.List;

@Transactional
@Component
public class TaskLifeCycleImpl {

    private static final Logger logger = LoggerFactory.getLogger(TaskLifeCycleImpl.class);

    private final BpmnInitializerService bpmnInitializerService;
    private final BpmnFileRepository bpmnFileRepository;

    public TaskLifeCycleImpl(BpmnInitializerService bpmnInitializerService,
                             BpmnFileRepository bpmnFileRepository) {
        this.bpmnInitializerService = bpmnInitializerService;
        this.bpmnFileRepository = bpmnFileRepository;
    }

    // ✅ NO synchronized — fully parallel
    public ProcessInstance createProcessInstance(TaskLifeCycleDto dto) {
        RuntimeEngine engine = bpmnInitializerService.getRuntimeEngineForNew();
        try {
            ProcessInstance pi = engine.getKieSession().startProcess(dto.getProcessId());
            if (logger.isInfoEnabled()) {
                logger.info("Process started: id={}, process={}", pi.getId(), dto.getProcessId());
            }
            return pi;
        } finally {
            bpmnInitializerService.disposeRuntimeEngine(engine);
        }
    }

    public TaskSummaryDto getTaskSummary(TaskLifeCycleDto dto) {
        RuntimeEngine engine = bpmnInitializerService.getRuntimeEngine(dto.getProcessInstanceId());
        try {
            TaskService taskService = engine.getTaskService();
            List tasks = taskService.getTasksByStatusByProcessInstanceId(
                    dto.getProcessInstanceId(),
                    List.of(Status.Created, Status.Reserved, Status.Ready),
                    "en");
            return new TaskSummaryDto(tasks);
        } finally {
            bpmnInitializerService.disposeRuntimeEngine(engine);
        }
    }

    public void startTask(TaskLifeCycleDto dto) {
        RuntimeEngine engine = bpmnInitializerService.getRuntimeEngine(dto.getProcessInstanceId());
        try {
            engine.getTaskService().start(dto.getTaskId(), dto.getUser());
        } finally {
            bpmnInitializerService.disposeRuntimeEngine(engine);
        }
    }

    public void claimTask(TaskLifeCycleDto dto) {
        RuntimeEngine engine = bpmnInitializerService.getRuntimeEngine(dto.getProcessInstanceId());
        try {
            engine.getTaskService().claim(dto.getTaskId(), dto.getUser());
        } finally {
            bpmnInitializerService.disposeRuntimeEngine(engine);
        }
    }

    public void activateTask(TaskLifeCycleDto dto) {
        RuntimeEngine engine = bpmnInitializerService.getRuntimeEngine(dto.getProcessInstanceId());
        try {
            engine.getTaskService().activate(dto.getTaskId(), dto.getUser());
        } finally {
            bpmnInitializerService.disposeRuntimeEngine(engine);
        }
    }

    public void completeTask(TaskLifeCycleDto dto) {
        RuntimeEngine engine = bpmnInitializerService.getRuntimeEngine(dto.getProcessInstanceId());
        try {
            engine.getTaskService().complete(dto.getTaskId(), dto.getUser(), dto.getGatewayVar());
        } finally {
            bpmnInitializerService.disposeRuntimeEngine(engine);
        }
    }

    public void addBusinessProcess(MultipartFile bpmnFile, String processId) throws IOException {
        BpmnFiles file = new BpmnFiles();
        file.setFileContent(new String(bpmnFile.getBytes(), StandardCharsets.UTF_8));
        file.setProcessId(processId);
        bpmnFileRepository.save(file);
        bpmnInitializerService.rebuild();
    }
}